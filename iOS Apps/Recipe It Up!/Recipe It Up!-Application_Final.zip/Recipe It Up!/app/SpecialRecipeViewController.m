//
//  SpecialRecipeViewController.m
//  Recipe It up!
//
//  Created by Mark Evans on 9/2/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

#import "SpecialRecipeViewController.h"
#import  <MediaPlayer/MediaPlayer.h>
#import <MessageUI/MessageUI.h>

@interface SpecialRecipeViewController ()

@end

@implementation SpecialRecipeViewController
@synthesize theTitleStr;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    if ([theNavbar respondsToSelector:@selector(setBackgroundImage:forBarMetrics:)] ) {
        UIImage *image = [UIImage imageNamed:@"navbar_blank.png"];
        [theNavbar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    }
    
    UIImage *image = [UIImage imageNamed:@"recipebg"];
    theTitle.text = theTitleStr;
    
    if ([theTitleStr isEqualToString:@"Shrimp Scampi"])
    {
        thetext = [[NSString alloc]initWithFormat:@"Ingredients\n1/3 cup butter or margarine\n2 green onions, sliced\n4 large garlic cloves, minced\n1 tablespoon grated lemon rind\n1/2 cup fresh lemon juice\n1/2 teaspoon salt\n1 3/4 pounds large fresh shrimp, peeled and deveined\n1/2 cup chopped fresh parsley\n1/2 teaspoon hot sauce\n12 ounces angel hair pasta, cooked\n\nPreparation\nMelt butter in a large skillet over medium-high heat; add green onions, minced garlic, lemon rind, lemon juice, and salt; cook garlic mixture 2 to 3 minutes or until bubbly.\n\nReduce heat to medium; add shrimp, and cook, stirring constantly, 5 minutes or just until shrimp turn pink. Stir in parsley and hot sauce. Toss with hot pasta.\n\nPrep: 10 min., Cook: 8 min."];
        textView.text = thetext;
        NSString *filePath = @"http://www.markevansjr.com/video/video_recipe_of_the_day.m4v";
        NSURL *fileURL = [NSURL URLWithString:filePath];
        moviePlayer = [[MPMoviePlayerController alloc]initWithContentURL:fileURL];
        if (moviePlayer != nil)
        {
            [movieView addSubview:moviePlayer.view];
            moviePlayer.view.frame = CGRectMake(0.0f, 0.0f, movieView.frame.size.width, movieView.frame.size.height);
            moviePlayer.view.backgroundColor = [UIColor colorWithPatternImage:image];
            moviePlayer.fullscreen = false;
            moviePlayer.controlStyle = MPMovieControlStyleDefault;
            [moviePlayer play];
        }
    }
    else
    {
        thetext2 = [[NSString alloc]initWithFormat:@"Ingredients\n\nCrumb crust\n8 ounces (15 4 3/4 x 2 1/2-inch sheets of graham cracker; yes, I am crazy enough to both count and measure) finely ground graham crackers or cookies such as chocolate or vanilla wafers\n8 tablespoons (1 stick or 4 ounces or 113 grams) unsalted butter, melted\n1/2 cup sugar\n1/4 teaspoon salt\n\nVery tall cheesecake filling:\n5 (8-ounce) packages cream cheese, softened (Philadelphia is recommended for cheesecakes but if you’ve had success with other brands, feel free to use them again)\n1 3/4 cups sugar\n3 tablespoons all-purpose flour\n1 teaspoon finely grated lemon zest\n1 teaspoon finely grated orange zest\n5 large eggs\n2 large egg yolks\n1/2 teaspoon vanilla\n\nCherry topping\n10 ounces sweet or sour cherries, pitted (they’re not in season here so I used frozen; worked just fine)\n2 tablespoons lemon juice\n1/4 cup sugar*\n1 tablespoon cornstarch\n1/2 cup water\n\nMake crumb crust: Stir together crust ingredients and press onto bottom and up the sides, stopping one inch shy of the top rim**, of a buttered 9 1/2-inch (or 24 cm) springform pan. You can fill it right away but I like to pop my into the freezer so it quickly sets while I prepare the filling.\n\nMake very tall cheesecake filling: Preheat oven to 550 degrees***. Beat together cream cheese, sugar, flour and zest with an electric mixer until smooth. Add vanilla, then eggs and yolks, one at a time, beating on low speed until each ingredient is incorporated. Scrape bowl down between additions; I cannot stress this enough as if you do not, you’ll end up with unmixed stripes of cream cheese. I always find at least one, despite my best efforts."];
        textView.text = thetext2;
        NSString *filePath = [[NSBundle mainBundle] pathForResource:@"video" ofType:@"mov"];
        NSURL *fileURL = [NSURL fileURLWithPath:filePath];
        moviePlayer = [[MPMoviePlayerController alloc]initWithContentURL:fileURL];
        if (moviePlayer != nil)
        {
            [movieView addSubview:moviePlayer.view];
            moviePlayer.view.frame = CGRectMake(0.0f, 0.0f, movieView.frame.size.width, movieView.frame.size.height);
            moviePlayer.view.backgroundColor = [UIColor colorWithPatternImage:image];
            moviePlayer.fullscreen = false;
            moviePlayer.controlStyle = MPMovieControlStyleDefault;
            [moviePlayer play];
        }
    }
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(IBAction)showaction
{
    popquery = [[UIActionSheet alloc] initWithTitle:@"" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Print Recipe" otherButtonTitles:@"Email Recipe", @"Open in Safari", nil];
    popquery.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [popquery showFromBarButtonItem:actionButton animated:true];
}

- (IBAction)print
{
    UIPrintInteractionController *print = [UIPrintInteractionController sharedPrintController];
    UIPrintInfo *printInfo = [UIPrintInfo printInfo];
    printInfo.outputType = UIPrintInfoOutputGeneral;
    
    print.printInfo = printInfo;
    print.printFormatter = [self.view viewPrintFormatter];
    print.showsPageRange = YES;
    
    void (^completionHandler)(UIPrintInteractionController *, BOOL, NSError *) =
    ^(UIPrintInteractionController *printController, BOOL completed, NSError *error)
    {
        if (!completed && error)
        {
            NSLog(@"Printing could not complete because of error: %@", error);
        }
    };
    [print presentAnimated:YES completionHandler:completionHandler];
}

- (void)pushSafari
{
    if ([theTitleStr isEqualToString:@"Shrimp Scampi"])
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.myrecipes.com/recipe/speedy-scampi-10000000264365/"]];
    }
    else
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://smittenkitchen.com/blog/2010/04/new-york-cheesecake/"]];
    }
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
    NSString *cancelTitle = [actionSheet buttonTitleAtIndex:buttonIndex];
	if([title isEqualToString:@"Print Recipe"])
	{
        [self print];
    }
    else if([title isEqualToString:@"Email Recipe"])
	{
        [self pushEmail];
    }
    else if([title isEqualToString:@"Open in Safari"])
	{
        [self pushSafari];
    }
    else if([cancelTitle isEqualToString:@"Cancel"])
    {
        NSLog(@"Cancel button clicked.");
    }
}

-(IBAction)pushEmail
{
    MFMailComposeViewController *mail = [[MFMailComposeViewController alloc] init];
    mail.mailComposeDelegate = self;
    if ([MFMailComposeViewController canSendMail])
    {
        if ([theTitleStr isEqualToString:@"Shrimp Scampi"])
        {
            //Setting up the Subject, recipients, and message body.
            NSString *formattMsg = [[NSString alloc]initWithFormat:@"Shrimp Scampi\n\nLink to Recipe:\nhttp://www.myrecipes.com/recipe/speedy-scampi-10000000264365/"];
            NSLog(@"%@", formattMsg);
            [mail setMessageBody:formattMsg isHTML:false];
            NSString *formatSub = [[NSString alloc]initWithFormat:@"Recipe: Shrimp Scampi"];
            [mail setSubject:formatSub];
            //[mail setToRecipients:[NSArray arrayWithObjects:@"mevansjr@gmail.com",nil]];
            //Present the mail view controller
            [self presentModalViewController:mail animated:YES];
            
            NSURL *picUrl = [NSURL URLWithString:@"http://img4-2.myrecipes.timeinc.net/i/recipes/sl/02/07/shrimp-scampi-sl-264365-l.jpg"];
            NSData *picData = [NSData dataWithContentsOfURL:picUrl];
            UIImage *pic = [[UIImage alloc] initWithData:picData];
            NSData *exportData = UIImageJPEGRepresentation(pic ,1.0);
            
            [mail addAttachmentData:exportData mimeType:@"image/jpeg" fileName:@"Picture.jpeg"];
        }
        else
        {
            //Setting up the Subject, recipients, and message body.
            NSString *formattMsg = [[NSString alloc]initWithFormat:@"New York Cheese Cake\n\nLink to Recipe:\nhttp://smittenkitchen.com/blog/2010/04/new-york-cheesecake/"];
            NSLog(@"%@", formattMsg);
            [mail setMessageBody:formattMsg isHTML:false];
            NSString *formatSub = [[NSString alloc]initWithFormat:@"Recipe: New York Cheese Cake"];
            [mail setSubject:formatSub];
            //[mail setToRecipients:[NSArray arrayWithObjects:@"mevansjr@gmail.com",nil]];
            //Present the mail view controller
            [self presentModalViewController:mail animated:YES];
            
            NSURL *picUrl = [NSURL URLWithString:@"http://www.flickr.com/photos/smitten/4483653731/"];
            NSData *picData = [NSData dataWithContentsOfURL:picUrl];
            UIImage *pic = [[UIImage alloc] initWithData:picData];
            NSData *exportData = UIImageJPEGRepresentation(pic ,1.0);
            
            [mail addAttachmentData:exportData mimeType:@"image/jpeg" fileName:@"Picture.jpeg"];
        }
    }
}

- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    [self dismissModalViewControllerAnimated:YES];
	if (result == MFMailComposeResultFailed)
    {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Email Failed!" message:@"Your email has failed to send" delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
		[alert show];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (IBAction)onClose:(id)sender
{
    [self dismissModalViewControllerAnimated:true];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    //return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft);
    return YES;
}

@end
