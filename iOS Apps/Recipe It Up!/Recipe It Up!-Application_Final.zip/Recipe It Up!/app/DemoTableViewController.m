//
// DemoTableViewController.m
//
//  Created by Mark Evans on 8/27/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

#import "DemoTableViewController.h"
#import "SpecialRecipeViewController.h"
#import "CustomCell.h"

#define kCellIdentifier  @"UITableViewCell"
#define kNavigationTitle @"Recipes of the Day"


@interface DemoTableViewController()

@property (nonatomic, readonly, retain) NSArray *texts;

+ (NSArray*)testData;
+ (NSArray*)testData2;
+ (NSArray*)testData3;

@end


@implementation DemoTableViewController {
@private
	NSArray *texts_;
    NSArray *texts2_;
    NSArray *texts3_;
}


- (void)dealloc {
	[texts_ release];
    [texts2_ release];
    [texts3_ release];
	[super dealloc];
}


#pragma mark -
#pragma mark Property


- (NSArray*)texts {
	if (texts_ == nil) {
		texts_ = [[DemoTableViewController testData] retain];
	}
	return texts_;
}

- (NSArray*)texts2 {
	if (texts2_ == nil) {
		texts2_ = [[DemoTableViewController testData2] retain];
	}
	return texts2_;
}

- (NSArray*)texts3 {
	if (texts3_ == nil) {
		texts3_ = [[DemoTableViewController testData3] retain];
	}
	return texts3_;
}

#pragma mark -


+ (NSArray*)testData {
	NSMutableArray *data = [[[NSMutableArray alloc] init] autorelease];
	
	NSString *entree = @"Shrimp Scampi";
    NSString *localDessert = @"New York Cheese Cake";
    [data addObject:entree];
    [data addObject:localDessert];
	
	return data;
}

+ (NSArray*)testData2 {
	NSMutableArray *data2 = [[[NSMutableArray alloc] init] autorelease];
	
	NSString *entree = @"Southern Living";
    NSString *localDessert = @"Smitten Kitchen";
    [data2 addObject:entree];
    [data2 addObject:localDessert];
	
	return data2;
}

+ (NSArray*)testData3 {
	NSMutableArray *data3 = [[[NSMutableArray alloc] init] autorelease];
	
	UIImage *imgdefault = [UIImage imageNamed:@"shrimppic.png"];
    UIImage *imgdefault2 = [UIImage imageNamed:@"cakepic.png"];
    [data3 addObject:imgdefault];
    [data3 addObject:imgdefault2];
	
	return data3;
}

#pragma mark -
#pragma mark UITableViewController


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [self.texts count];
}


- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath {
	NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
    CustomCell *cell = (CustomCell *)[nib objectAtIndex:0];
    if (cell != nil)
    {
        UIImage *imgdefault = [self.texts3 objectAtIndex:[indexPath row]];
        [cell.thumbnailPic setImage:imgdefault];
        [cell.starControl setHidden:true];
        NSString *text = [self.texts objectAtIndex:[indexPath row]];
        NSString *text2 = [self.texts2 objectAtIndex:[indexPath row]];
        cell.statusLabel.text = text;
        cell.sourceLabel.text = text2;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 65.0f;
}


- (void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath {
	[tableView deselectRowAtIndexPath:indexPath
							 animated:YES];
	SpecialRecipeViewController *recipeOfTheDayView = [[SpecialRecipeViewController alloc]init];
    [recipeOfTheDayView setTheTitleStr:[self.texts objectAtIndex:[indexPath row]]];
    [self presentModalViewController:recipeOfTheDayView animated:true];
}


#pragma mark -
#pragma mark UIViewController


- (void)viewDidLoad {
	[super viewDidLoad];
	[self.navigationItem setTitle:kNavigationTitle];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return YES;
}


@end
